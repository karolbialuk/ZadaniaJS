const tablica = [
    {wzrost: 155, wiek:20, bmi: 150, waga: 70, imie: 'adam', miasto: 'gdansk'},
    {wzrost: 140, wiek:25, bmi: 350, waga: 62, imie: 'michał', miasto: 'gdynia'},
    {wzrost: 185,   wiek:29, bmi: 90, waga: 120, imie: 'bartek', miasto: 'sopot'},
    {wzrost:176,   wiek:38, bmi: 32, waga: 129, imie: 'agata', miasto: 'lomza'},
    {wzrost:132,   wiek:48, bmi: 55, waga: 130, imie: 'zenek', miasto: 'warszawa'},
    {wzrost:144,   wiek:22, bmi: 100, waga: 144, imie: 'karol', miasto: 'bialystok'},
    {wzrost:187,   wiek:15, bmi: 90, waga: 152, imie: 'jan', miasto: 'krakow'},
    {wzrost:112,   wiek:29, bmi: 60, waga: 78, imie: 'zbigniew', miasto: 'poznan'},
    {wzrost:210,   wiek:58, bmi: 72, waga: 91, imie: 'amelia', miasto: 'ostroleka'},
    {wzrost:199,   wiek:60, bmi: 79, waga: 70, imie: 'aleksandra', miasto: 'wroclaw'},

    ];


function wprowadzDane() {
    var table = document.getElementById("dane");
    table.innerHTML="";
     var tr="";
         tablica.forEach(x=>{
            tr+='<tr>';
            tr+='<td>'+x.wzrost+'</td>'+'<td>'+x.wiek+'</td>'+'<td>'+x.bmi+'</td>' + '<td>'+x.waga+'</td>' + '<td>'+x.imie+'</td>' + '<td>'+x.miasto+'</td>'
            tr+='</tr>'
                  
        })
           table.innerHTML+=tr;
        }

   wprowadzDane();

    
     
    function sortuj(property){  
            return function(a,b){  
               if(a[property] > b[property])  
                  return 1;  
               else if(a[property] < b[property])  
                  return -1;  
           
               return 0;  
            }  
         }  

    

    const sortowanko = () => {
            var wybieranie = document.getElementById('wybieranie');
            var wartosc = wybieranie.options[wybieranie.selectedIndex].value;
             tablica.sort(sortuj(wartosc))
             var table = document.getElementById("dane");
            table.innerHTML="";
            var tr="";
         tablica.forEach(x=>{
            tr+='<tr>';
            tr+='<td>'+x.wzrost+'</td>'+'<td>'+x.wiek+'</td>'+'<td>'+x.bmi+'</td>' + '<td>'+x.waga+'</td>' + '<td>'+x.imie+'</td>' + '<td>'+x.miasto+'</td>'
            tr+='</tr>'
                  
        })
           table.innerHTML+=tr;
    }



    function sortuj2(property){  
        return function(a,b){  
           if(a[property] < b[property])  
              return 1;  
           else if(a[property] > b[property])  
              return -1;  
       
           return 0;  
        }  
     }  


     const sortowanko2 = () => {
        var wybieranie2 = document.getElementById('wybieranie2');
        var wartosc2 = wybieranie2.options[wybieranie2.selectedIndex].value;
         tablica.sort(sortuj2(wartosc2))
         var table = document.getElementById("dane");
        table.innerHTML="";
        var tr="";
     tablica.forEach(x=>{
        tr+='<tr>';
        tr+='<td>'+x.wzrost+'</td>'+'<td>'+x.wiek+'</td>'+'<td>'+x.bmi+'</td>' + '<td>'+x.waga+'</td>' + '<td>'+x.imie+'</td>' + '<td>'+x.miasto+'</td>'
        tr+='</tr>'
              
    })
       table.innerHTML+=tr;
}


const alfabetycznie = () => {
    var wybieranie3 = document.getElementById('wybieranie3');
        var wartosc3 = wybieranie3.options[wybieranie3.selectedIndex].value;
         tablica.sort(sortuj(wartosc3))
         var table = document.getElementById("dane");
        table.innerHTML="";
        var tr="";
     tablica.forEach(x=>{
        tr+='<tr>';
        tr+='<td>'+x.wzrost+'</td>'+'<td>'+x.wiek+'</td>'+'<td>'+x.bmi+'</td>' + '<td>'+x.waga+'</td>' + '<td>'+x.imie+'</td>' + '<td>'+x.miasto+'</td>'
        tr+='</tr>'
              
    })
       table.innerHTML+=tr;

}

const alfabetycznie2 = () => {
var wybieranie4 = document.getElementById('wybieranie4');
var wartosc4 = wybieranie4.options[wybieranie4.selectedIndex].value;
tablica.sort(sortuj2(wartosc4))
var table = document.getElementById("dane");
table.innerHTML="";
var tr="";
 tablica.forEach(x=>{
    tr+='<tr>';
    tr+='<td>'+x.wzrost+'</td>'+'<td>'+x.wiek+'</td>'+'<td>'+x.bmi+'</td>' + '<td>'+x.waga+'</td>' + '<td>'+x.imie+'</td>' + '<td>'+x.miasto+'</td>'
    tr+='</tr>'
          
})
   table.innerHTML+=tr;
}


function sprawdztekst(property, tekst){
   return function(a){
      if(a[property].includes(tekst))
         return 1;
      return 0;
   }
}


const text = () => {
   var wybieranie5 = document.getElementById('wybieranie5');
   var wartosc5 = wybieranie5.options[wybieranie5.selectedIndex].value;
   var tekst = document.getElementById('tekst').value;

   const tablicanowa = tablica.filter(sprawdztekst(wartosc5, tekst));
   console.log(tablica.filter(sprawdztekst(wartosc5, tekst)));

   var table = document.getElementById("dane2");
   table.innerHTML="";
   var tr="";
   tablicanowa.forEach(x=>{
      tr+='<tr>';
      tr+='<td>'+x.wzrost+'</td>'+'<td>'+x.wiek+'</td>'+'<td>'+x.bmi+'</td>' + '<td>'+x.waga+'</td>' + '<td>'+x.imie+'</td>' + '<td>'+x.miasto+'</td>'
      tr+='</tr>'
            
   })
      table.innerHTML+=tr;
}




function funkcjawiekszeod(property, liczba){  
   return function(a){  
      if(a[property] > liczba)  
         return 1;  
      return 0;  
   }  
}  


const wiekszeod = () => {
var wybieranie6 = document.getElementById('wybieranie6');
var wartosc6 = wybieranie6.options[wybieranie6.selectedIndex].value;
var wiekszyod = document.getElementById('wiekszyod').value;
console.log(wiekszyod)

const tablicanowa = tablica.filter(funkcjawiekszeod(wartosc6, wiekszyod));

console.log(tablica.filter(funkcjawiekszeod(wartosc6, wiekszyod)));

var table = document.getElementById("dane2");

table.innerHTML="";
var tr="";
tablicanowa.forEach(x=>{
   tr+='<tr>';
   tr+='<td>'+x.wzrost+'</td>'+'<td>'+x.wiek+'</td>'+'<td>'+x.bmi+'</td>' + '<td>'+x.waga+'</td>' + '<td>'+x.imie+'</td>' + '<td>'+x.miasto+'</td>'
   tr+='</tr>'
         
})
  table.innerHTML+=tr;
}


function funkcjamniejszeod(property, liczba){  
   return function(a){  
      if(a[property] < liczba)  
         return 1;  
        
  
      return 0;  
   }  
}  


const mniejszeod = () => {
   var wybieranie7 = document.getElementById('wybieranie7');
   var wartosc7 = wybieranie7.options[wybieranie7.selectedIndex].value;
   var mniejszyod = document.getElementById('mniejszyod').value;

   const tablicanowa = tablica.filter(funkcjamniejszeod(wartosc7, mniejszyod));

   var table = document.getElementById("dane2");

   table.innerHTML="";
   var tr="";
   tablicanowa.forEach(x=>{
      tr+='<tr>';
      tr+='<td>'+x.wzrost+'</td>'+'<td>'+x.wiek+'</td>'+'<td>'+x.bmi+'</td>' + '<td>'+x.waga+'</td>' + '<td>'+x.imie+'</td>' + '<td>'+x.miasto+'</td>'
      tr+='</tr>'
            
   })
  table.innerHTML+=tr;
   
}


const liczsume = () => {
   
   var mojaTabelka = document.getElementById('tabelka-druga');
  
   var suma = tablica.reduce(function(_this, tabela) {
      return _this + tabela.wzrost
   }, 0);

   mojaTabelka.rows[1].cells[0].innerHTML = suma;

  var suma2 = tablica.reduce(function(_this, tabela) {
   return _this + tabela.wiek
   }, 0);

   mojaTabelka.rows[1].cells[1].innerHTML = suma2;

   var suma3 = tablica.reduce(function(_this, tabela) {
      return _this + tabela.bmi
   }, 0);

   mojaTabelka.rows[1].cells[2].innerHTML = suma3;

   var suma4 = tablica.reduce(function(_this, tabela) {
      return _this + tabela.waga
   }, 0);

   mojaTabelka.rows[1].cells[3].innerHTML = suma4;

}

liczsume();
