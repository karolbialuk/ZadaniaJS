var tablica = [

];

function edytuj_wiersz(no){
    document.getElementById("edytuj_button"+no).style.display="none";
    document.getElementById("zapisz_button"+no).style.display="inline-block";
        
    var nazwaproduktu=document.getElementById("nazwaproduktu_row"+no);
    var marka=document.getElementById("marka_row"+no);
    var waga=document.getElementById("waga_row"+no);
    var kolor=document.getElementById("kolor_row"+no);
    var data=document.getElementById("data_row"+no);
    var cena=document.getElementById("cena_row"+no);
        
    var nazwaproduktu_data=nazwaproduktu.innerHTML;
    var marka_data=marka.innerHTML;
    var waga_data=waga.innerHTML;
    var kolor_data=kolor.innerHTML;
    var data_data=data.innerHTML;
    var cena_data=cena.innerHTML;


        
    nazwaproduktu.innerHTML="<input type='text' id='nazwaproduktu_text"+no+"' value='"+nazwaproduktu_data+"'>";
    marka.innerHTML="<input type='text' id='marka_text"+no+"' value='"+marka_data+"'>";
    marka.innerHTML='<select name="marka" id="marka_text"'+no+'placeholder="Marka"><option value="samsung">Samsung</option><option value="apple">Apple</option><option value="sony">Sony</option><option value="huawei">Huawei</option><option value="xiaomi">Xiaomi</option></select>'
    waga.innerHTML="<input type='number' id='waga_text"+no+"' value='"+waga_data+"'>";
    kolor.innerHTML="<input type='color' id='kolor_text"+no+"' value='"+kolor_data+"'>";
    data.innerHTML="<input type='date' id='data_text"+no+"' value='"+data_data+"'>";
    cena.innerHTML="<input type='text' id='cena_text"+no+"' value='"+cena_data+"'>";
}


function zapisz_wiersz(no){

    var nazwaProduktu = document.getElementById("nazwaproduktu_row"+no).innerHTML;
    var marka = document.getElementById("marka_row"+no).innerHTML;
    var waga = document.getElementById("waga_row"+no).innerHTML;
    var kolor = document.getElementById("kolor_row"+no).innerHTMLL;
    var data = document.getElementById("data_row"+no).innerHTML;
    var cena = document.getElementById("cena_row"+no).innerHTML;

    var myObj = {
        "nazwaProduktu" : nazwaProduktu,
        "marka" : marka,
        "waga" : waga,
        "kolor" : kolor,
        "data" : data,
        "cena" : cena
    };

    tablica.pop(myObj);


    var nazwaproduktu_val=document.getElementById("nazwaproduktu_text"+no).value;

    var wybieranie = document.getElementById('marka_text');
    var marka_val = wybieranie.options[wybieranie.selectedIndex].value;

    var waga_val=document.getElementById("waga_text"+no).value;
    var kolor_val=document.getElementById("kolor_text"+no).value;
    var data_val=document.getElementById("data_text"+no).value;
    var cena_val=document.getElementById("cena_text"+no).value;

    var myObj2 = {
        "nazwaProduktu" : nazwaproduktu_val,
        "marka" : marka_val,
        "waga" : waga_val,
        "kolor" : kolor_val,
        "data" : data_val,
        "cena" : cena_val
    };

    tablica.push(myObj2);

    document.getElementById("nazwaproduktu_row"+no).innerHTML=nazwaproduktu_val;
    document.getElementById("marka_row"+no).innerHTML=marka_val;
    document.getElementById("waga_row"+no).innerHTML=waga_val;
    document.getElementById("kolor_row"+no).innerHTML=kolor_val;
    document.getElementById("kolor_row"+no).style = `background-color: ${kolor_val}`;
    document.getElementById("data_row"+no).innerHTML=data_val;
    document.getElementById("cena_row"+no).innerHTML=cena_val;

    
    document.getElementById("edytuj_button"+no).style.display="inline-block";
    document.getElementById("zapisz_button"+no).style.display="inline-block";
}

    function usun_wiersz(no)
        {
            var potwierdzenie = confirm("Czy napewno chcesz usunąć wiersz?")
            if(potwierdzenie){
                document.getElementById("row"+no+"").outerHTML="";


            }
        }


    function dodaj_wiersz(){
        var new_nazwaproduktu=document.getElementById("new_nazwaproduktu").value;

        var wybieranie = document.getElementById('new_marka');
        var new_marka = wybieranie.options[wybieranie.selectedIndex].value;

        var new_waga=document.getElementById("new_waga").value;
        var new_kolor=document.getElementById("new_kolor").value;
        var new_data=document.getElementById("new_data").value;
        var new_cena=document.getElementById("new_cena").value;
            
        var table=document.getElementById("dane");
        var table_len=(table.rows.length)-1;
        var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='nazwaproduktu_row"+table_len+"'>"+new_nazwaproduktu+"</td><td id='marka_row"+table_len+"'>"+new_marka+"</td><td id='waga_row"+table_len+"'>"+new_waga+"</td><td style='background-color: "+new_kolor+"' id='kolor_row"+table_len+"'>"+new_kolor+"</td><td id='data_row"+table_len+"'>"+new_data+"</td><td id='cena_row"+table_len+"'>"+new_cena+"</td><td><input type='button' id='edytuj_button"+table_len+"' value='Edytuj' class='edit' onclick='edytuj_wiersz("+table_len+")'> <input type='button' id='zapisz_button"+table_len+"' value='Zapisz' class='save' onclick='zapisz_wiersz("+table_len+")'> <input type='button' value='Usuń' id='usun"+table_len+"' class='delete' onclick='usun_wiersz("+table_len+")'><input type='button' value='Powiel' id='powiel"+table_len+"' class='powiel' onclick='powiel_wiersz("+table_len+")'></td></tr>";

        document.getElementById("new_nazwaproduktu").value="";
        document.getElementById("new_waga").value="";
        document.getElementById("new_kolor").value="#000000";
        document.getElementById("new_data").value="";
        document.getElementById("new_cena").value="";
    }


   

    function powiel_wiersz(no){
        var nazwaproduktu=document.getElementById("nazwaproduktu_row"+no);
        var marka=document.getElementById("marka_row"+no);
        var waga=document.getElementById("waga_row"+no);
        var kolor=document.getElementById("kolor_row"+no);
        var data=document.getElementById("data_row"+no);
        var cena=document.getElementById("cena_row"+no);
            
        var nazwaproduktu_data=nazwaproduktu.innerHTML;
        var marka_data=marka.innerHTML;
        var waga_data=waga.innerHTML;
        var kolor_data=kolor.innerHTML;
        var data_data=data.innerHTML;
        var cena_data=cena.innerHTML;

        var myObj2 = {
            "nazwaProduktu" : nazwaproduktu_data,
            "marka" : marka_data,
            "waga" : waga_data,
            "kolor" : kolor_data,
            "data" : data_data,
            "cena" : cena_data
        };

    tablica.push(myObj2);

    var table=document.getElementById("dane");
    var table_len=(table.rows.length)-1;
    var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='nazwaproduktu_row"+table_len+"'>"+nazwaproduktu_data+"</td><td id='marka_row"+table_len+"'>"+marka_data+"</td><td id='waga_row"+table_len+"'>"+waga_data+"</td><td style='background-color: "+kolor_data+"' id='kolor_row"+table_len+"'>"+kolor_data+"</td><td id='data_row"+table_len+"'>"+data_data+"</td><td id='cena_row"+table_len+"'>"+cena_data+"</td><td><input type='button' id='edytuj_button"+table_len+"' value='Edytuj' class='edit' onclick='edytuj_wiersz("+table_len+")'> <input type='button' id='zapisz_button"+table_len+"' value='Zapisz' class='save' onclick='zapisz_wiersz("+table_len+")'> <input type='button' value='Usuń' class='delete' onclick='usun_wiersz("+table_len+")'> <input type='button' value='Powiel' class='powiel' onclick='powiel_wiersz("+table_len+")'></td></tr>";


}
    

    
    const eksportuj = () =>{
        var table = document.getElementById("dane");
        for (let i in table.rows) {
            let row = table.rows[i]

            var nazwaProduktu = row.cells[0].innerHTML;
            var marka = row.cells[1].innerHTML;
            var waga = row.cells[2].innerHTML;
            var kolor = row.cells[3].innerHTML;
            var data = row.cells[4].innerHTML;
            var cena = row.cells[5].innerHTML;

            var myObj = {
                "nazwaProduktu" : nazwaProduktu,
                "marka" : marka,
                "waga" : waga,
                "kolor" : kolor,
                "data" : data,
                "cena" : cena
            };
        
            for (let j in row.cells) {
                let col = row.cells[j]
                
            }  
            tablica.push(myObj);
            
            console.log(tablica[i]);
            
        }

    }

    
    const importuj = () =>{
    const powiadomienie = prompt("Podaj 6 elementów do importu po spacji");
    
    const slowo = powiadomienie.split(' ');

    var new_nazwaproduktu=slowo[0];
    var new_marka=slowo[1];
    var new_waga=slowo[2];
    var new_kolor=slowo[3];
    var new_data=slowo[4];
    var new_cena=slowo[5];

    var myObj = {
        "nazwaProduktu" : new_nazwaproduktu,
        "marka" : new_marka,
        "waga" : new_nazwaproduktu,
        "kolor" : new_nazwaproduktu,
        "data" : new_data,
        "cena" : new_nazwaproduktu
    };

    tablica.push(myObj);

    var table=document.getElementById("dane");
    var table_len=(table.rows.length)-1;
    var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='nazwaproduktu_row"+table_len+"'>"+new_nazwaproduktu+"</td><td id='marka_row"+table_len+"'>"+new_marka+"</td><td id='waga_row"+table_len+"'>"+new_waga+"</td><td id='kolor_row"+table_len+"'>"+new_kolor+"</td><td id='data_row"+table_len+"'>"+new_data+"</td><td id='cena_row"+table_len+"'>"+new_cena+"</td><td><input type='button' id='edytuj_button"+table_len+"' value='Edytuj' class='edit' onclick='edytuj_wiersz("+table_len+")'> <input type='button' id='zapisz_button"+table_len+"' value='Zapisz' class='save' onclick='zapisz_wiersz("+table_len+")'> <input type='button' value='Usuń' class='delete' onclick='usun_wiersz("+table_len+")'> <input type='button' value='Powiel' class='powiel' onclick='powiel_wiersz("+table_len+")'></td></tr>";
    
    console.log(slowo);
}




















