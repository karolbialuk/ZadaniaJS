const menu = document.querySelector('#mobile-menu');
const navbarMenu = document.querySelector('.navbar_menu');
const linkMenu = document.querySelector('#link_menu');
const linkMenu2 = document.querySelector('#link_menu2');
const linkMenu3 = document.querySelector('#link_menu3');

const toggle = () => {
    menu.classList.toggle('mobile-aktywny');
    navbarMenu.classList.toggle('navbar-aktywny');
}

menu.addEventListener('click', toggle)

const toggle2 = () => {
    linkMenu.classList.toggle('link-aktywny');
    linkMenu2.classList.remove('link-aktywny');
    linkMenu3.classList.remove('link-aktywny');
}

const toggle3 = () => {
    linkMenu.classList.remove('link-aktywny');
    linkMenu2.classList.toggle('link-aktywny');
    linkMenu3.classList.remove('link-aktywny')
}

const toggle4 = () => {
    linkMenu.classList.remove('link-aktywny');
    linkMenu2.classList.remove('link-aktywny');
    linkMenu3.classList.toggle('link-aktywny');
}

const toggle5 = () => {
    linkMenu.classList.remove('link-aktywny');
    linkMenu2.classList.remove('link-aktywny');
    linkMenu3.classList.remove('link-aktywny');
}

document.querySelector('.hero','rozgrywka').addEventListener('click', toggle5)

document.getElementById('arrow-rozgrywka').addEventListener('click', toggle2);
document.getElementById('arrow-historia').addEventListener('click', toggle3);
document.getElementById('arrow-adaptacje').addEventListener('click', toggle4);

function reveal(){
    var reveal = document.querySelector('.rozgrywka_img');
    
        var windowheight = window.innerHeight;
        var revealtop = reveal.getBoundingClientRect().top;
        var revealpoint = 150;

        if(revealtop < windowheight - revealpoint){
            reveal.classList.add('active');
        }else{
            reveal.classList.remove('active');
        }
    }

    window.addEventListener('scroll', reveal)

function reveal2(){
    var reveal = document.querySelector('#mechanika');
    
        var windowheight = window.innerHeight;
        var revealtop = reveal.getBoundingClientRect().top;
        var revealpoint = 120;

        if(revealtop < windowheight - revealpoint){
            reveal.classList.add('active');
        }else{
            reveal.classList.remove('active');
        }
    }

window.addEventListener('scroll', reveal2)


function reveal3(){
    var reveal = document.querySelector('#karty');
    
        var windowheight = window.innerHeight;
        var revealtop = reveal.getBoundingClientRect().top;
        var revealpoint = 120;

        if(revealtop < windowheight - revealpoint){
            reveal.classList.add('active');
        }else{
            reveal.classList.remove('active');
        }
    }

window.addEventListener('scroll', reveal3)


function reveal4(){
    var reveal = document.querySelector('#zeszyt');
    
        var windowheight = window.innerHeight;
        var revealtop = reveal.getBoundingClientRect().top;
        var revealpoint = 120;

        if(revealtop < windowheight - revealpoint){
            reveal.classList.add('active');
        }else{
            reveal.classList.remove('active');
        }
    }

window.addEventListener('scroll', reveal4)

function reveal5(){
    var reveal = document.querySelector('.napis_img');
    
        var windowheight = window.innerHeight;
        var revealtop = reveal.getBoundingClientRect().top;
        var revealpoint = 120;

        if(revealtop < windowheight - revealpoint){
            reveal.classList.add('active');
        }else{
            reveal.classList.remove('active');
        }
    }

window.addEventListener('scroll', reveal5)

function reveal6(){
    var reveal = document.querySelector('.gry');
    
        var windowheight = window.innerHeight;
        var revealtop = reveal.getBoundingClientRect().top;
        var revealpoint = 120;

        if(revealtop < windowheight - revealpoint){
            reveal.classList.add('active');
        }else{
            reveal.classList.remove('active');
        }
    }

window.addEventListener('scroll', reveal6)


const domyslny = () => {
    document.documentElement.setAttribute("data-theme", "domyslny")
    localStorage.setItem("data-theme", "domyslny")
}

const jasny = () => {
    document.documentElement.setAttribute("data-theme", "jasny")
    localStorage.setItem("data-theme", "jasny")
}

const niebieski = () => {
    document.documentElement.setAttribute("data-theme", "niebieski")
    localStorage.setItem("data-theme", "niebieski")
}

const kolorowy = () => {
    document.documentElement.setAttribute("data-theme", "kolorowy")
    localStorage.setItem("data-theme", "kolorowy")
}







function motywy(el) {
    const option = el.value;
    if (option === 'jasny'){
        jasny();
    } else if(option ==='domyslny'){
        domyslny();
    } else if(option ==='niebieski'){
        niebieski();
    }else if(option ==='kolorowy'){
        kolorowy();
    }
    return console.log("essa");
  }


  const motywOnLoad = () =>{
    let motyw = localStorage.getItem('data-theme');
    if (motyw ==='jasny'){
        jasny()
    }else if (motyw ==='domyslny'){
        domyslny();
    } else if (motyw ==='niebieski'){
        niebieski();
    } else if (motyw ==='kolorowy'){
        kolorowy();
    }  
  }

  motywOnLoad();