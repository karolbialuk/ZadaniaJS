class uzytkownik {

        ustawProfil(nazwa, email, stronainternetowa, miejscezamieszkania, dataurodzenia, sygnatura) {
        this.nazwa = nazwa;
        this.email = email;
        this.stronainternetowa = stronainternetowa;
        this.miejscezamieszkania = miejscezamieszkania;
        this.dataurodzenia = dataurodzenia;
        this.sygnatura = sygnatura;

        this.zapiszProfil();
    }

    zapiszProfil() {
        
        let zapisanyEmail = document.getElementById('email').value;

        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(zapisanyEmail)){
        localStorage.setItem('email', zapisanyEmail);

        let zapisanaNazwa = document.getElementById('nazwa').value;
        localStorage.setItem('nazwa', zapisanaNazwa);

        let zapisanaStrona = document.getElementById('stronainternetowa').value;
        localStorage.setItem('stronainternetowa', zapisanaStrona);

        let zapisaneMiejsce = document.getElementById('miejscezamieszkania').value;
        localStorage.setItem('miejscezamieszkania', zapisaneMiejsce);

        let zapisanaData = document.getElementById('dataurodzenia').value;
        localStorage.setItem('dataurodzenia', zapisanaData);

        let zapisanaSygnatura = document.getElementById('sygnatura').value;
        localStorage.setItem('sygnatura', zapisanaSygnatura);

       alert('Zapisano pomyslnie')

        }else
        alert("Email nieprawidlowy! nie wprowadzono zmian")

        
    }

    pobierzProfil() {
        document.getElementById("nazwa").value = localStorage.getItem('nazwa');
        document.getElementById("email").value = localStorage.getItem('email');
        document.getElementById("stronainternetowa").value = localStorage.getItem('stronainternetowa');
        document.getElementById("miejscezamieszkania").value =localStorage.getItem('miejscezamieszkania');
        document.getElementById("dataurodzenia").value = localStorage.getItem('dataurodzenia');
        document.getElementById("sygnatura").value =localStorage.getItem('sygnatura'); 
    }

    

}


function aktualizujProfil() {
    mojProfil = new uzytkownik();
        mojProfil.ustawProfil();

        var nazwaprofilu = localStorage.getItem('nazwa');
        var emailprofilu = localStorage.getItem('email');
        var stronaprofilu = localStorage.getItem('stronainternetowa');
        var miejsceprofilu = localStorage.getItem('miejscezamieszkania');
        var dataprofilu = localStorage.getItem('dataurodzenia');
        var sygnaturaprofilu = localStorage.getItem('sygnatura');

        document.getElementById('pokaznazwa').innerHTML = nazwaprofilu;
        document.getElementById('pokazadres').innerHTML = emailprofilu;
        document.getElementById('pokazstrona').innerHTML = stronaprofilu;
        document.getElementById('pokazmiejscezamieszkania').innerHTML = miejsceprofilu;
        document.getElementById('pokazdataurodzenia').innerHTML = dataprofilu;
        document.getElementById('pokazsygnatura').innerHTML = sygnaturaprofilu;
}

function wyswietlProfil() {
  m = new uzytkownik();
  console.log(m) 
    m.pobierzProfil();
}

